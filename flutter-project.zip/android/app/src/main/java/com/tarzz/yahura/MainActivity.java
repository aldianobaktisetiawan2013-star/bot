package com.tarzz.yahura;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
